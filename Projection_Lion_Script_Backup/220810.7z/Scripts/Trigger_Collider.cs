using UnityEngine;
/// <summary>
///  
/// </summary>
public class Trigger_Collider : MonoBehaviour
{
    #region Ĳ�o
    #endregion

    #region �I��


    #endregion
    #region ��k


    #endregion
}
